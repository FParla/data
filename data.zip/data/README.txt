
#--------------------------------------------------------------------------------------------------------------------
# Macroeconomic data for:
#
# Temperature and Growth: a Panel Mixed Frequency VAR Analysis using NUTS2 data
#
# A. Cipollini and F. Parla, 2023
#--------------------------------------------------------------------------------------------------------------------
#
# This README file contains information on the macroeconomic variables used in the empirical analysis of the paper
# titled "Temperature and Growth: a Panel Mixed Frequency VAR Analysis using NUTS2 data".
# Data are for 225 NUTS2 regions and they are observed over the period 1981-2019.
#
# The variables are contained in "macrodataeu.xlsx". In particular, in the first column of the spreadsheet, we report
# the Eurostat NUTS 2021 code of the 225 NUTS2 regions. Notice that the only exception is for the NUTS 2016 code of 
# the Kontinentalna Hrvatska (HR04) region used by both the ARDECO and Copernicus climate change service (C3S) 
# operational energy databases. In the the second column we report the years, while in the following columns, we report 
# data for the following variables (in decimal): 
#
#--------------------------------------------------------------------------------------------------------------------
# Aggregate GVA, GVA per capita and GVA per employee
#
# 1. DIFF_LOG_GVA_REAL: first difference of log transform of Gross Value Added (GVA)
# 2. DIFF_LOG_GVA_REAL_PERCAPITA: first difference of log transform of GVA per capita 
# 3. DIFF_LOG_GVA_REAL_EMPLOYEE: first difference of log transform of GVA per employee
#
# GVA and GVA per employee for different NACE2 sectors
#
# 4. DIFF_LOG_GVA_REAL_AGRICULTURE: first difference of log transform of GVA for Agriculture, Forestry and Fishing
# 5. DIFF_LOG_GVA_REAL_AGRICULTURE_EMPLOYEE: first difference of log transform of GVA for Agriculture, Forestry and Fishing per employee
#
# 6. DIFF_LOG_GVA_REAL_INDUSTRY: first difference of log transform of GVA for Industry - excluding Construction
# 7. DIFF_LOG_GVA_REAL_INDUSTRY_EMPLOYEE: first difference of log transform of GVA for Industry - excluding Construction per employee	
#
# 8. DIFF_LOG_GVA_REAL_CONSTRUCTION: first difference of log transform of GVA for Construction
# 9. DIFF_LOG_GVA_REAL_CONSTRUCTION_EMPLOYEE: first difference of log transform of GVA for Construction per employee	
#
# 10.DIFF_LOG_GVA_REAL_WHOLESALE: first difference of log transform of GVA for Wholesale, Retail, Transport, Accommodation & Food Services, Information and Communication	
# 11.DIFF_LOG_GVA_REAL_WHOLESALE_EMPLOYEE: first difference of log transform of GVA for Wholesale, Retail, Transport, Accommodation & Food Services, Information and Communication per employee	
#
# 12.DIFF_LOG_GVA_REAL_MKT_SERVICES: first difference of log transform of GVA for Financial & Business Services	
# 13.DIFF_LOG_GVA_REAL_MKT_SERVICES_EMPLOYEE: first difference of log transform of GVA for Financial & Business Services per employee	
#
# 14.DIFF_LOG_GVA_REAL_NO_MKT_SERVICES: first difference of log transform of GVA for Non-market Services	
# 15.DIFF_LOG_GVA_REAL_NO_MKT_SERVICES_EMPLOYEE: first difference of log transform of GVA for Non-market Services per employee
#
#--------------------------------------------------------------------------------------------------------------------
# Notes.
# The raw data can be downloaded at the following link:
# https://urban.jrc.ec.europa.eu/ardeco/manager?lng=en

